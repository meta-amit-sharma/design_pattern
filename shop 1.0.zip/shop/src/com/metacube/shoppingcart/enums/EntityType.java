package com.metacube.shoppingcart.enums;

/**
 * stores the type of entity as a data member
 * 
 * @author Amit Sharma
 *
 */
public enum EntityType {
	Product,
	User,
	Cart;
}
