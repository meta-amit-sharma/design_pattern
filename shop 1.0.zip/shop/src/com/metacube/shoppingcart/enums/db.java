package com.metacube.shoppingcart.enums;

public enum db {
	InMemory , Sql;
}
