package com.metacube.shoppingcart.enums;

/**
 * stores the type of storage type as a data member
 * 
 * @author Amit Sharma
 *
 */
public enum DataBase {
	InMemory , Sql;
}
