package com.metacube.shoppingcart.enums;

public enum status {
	Product_added,
	Product_removed,
	No_such_product_found,
	Update_successfull;
}
