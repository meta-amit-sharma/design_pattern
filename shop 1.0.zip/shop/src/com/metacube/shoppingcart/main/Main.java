package com.metacube.shoppingcart.main;

import com.metacube.shoppingcart.view.Input;

public class Main {
	public static void main(String[] args){
		Input shop = new Input();
		shop.takeInput();
	}
	
}
