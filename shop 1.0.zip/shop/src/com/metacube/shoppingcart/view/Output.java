package com.metacube.shoppingcart.view;

public class Output {

}
