package com.metacube.shoppingcart.facade;

import java.util.Map;

import com.metacube.shoppingcart.entity.Product;
import com.metacube.shoppingcart.entity.ShoppingCart;
import com.metacube.shoppingcart.enums.OperationStatus;

public interface ShoppingFacade {

	public static ShoppingFacadeImp getInstance(){
		return ShoppingFacadeImp.getInstance();
	}
	
	public Map<Product, Integer> getList(String userID);
	
	public float getTotPrice (String userID);
	
	public Map<Product, Integer> addCart(String userID, ShoppingCart cart);
	
	public OperationStatus removeCart(String usreID);
	
	public OperationStatus addToCart(String userID, int productID, int quantity );
	
	public OperationStatus removeFromCart(String userID, int productID );
	
	public boolean checkUser(String userID);
}
