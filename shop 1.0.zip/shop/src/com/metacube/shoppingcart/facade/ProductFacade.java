package com.metacube.shoppingcart.facade;

import java.util.List;

import com.metacube.shoppingcart.entity.Product;
import com.metacube.shoppingcart.enums.OperationStatus;

public interface ProductFacade {

	public static ProductFacadeImp getInstance(){
		return ProductFacadeImp.getInstance();
	}
	
	public List<Product> getAll();
	
	public Product getProduct(int productId);
	
	public OperationStatus addProduct(Product product);
	
	public OperationStatus removeProduct(int productId);
	
	public OperationStatus updateProduct(int productId, String productName, float price );
}
