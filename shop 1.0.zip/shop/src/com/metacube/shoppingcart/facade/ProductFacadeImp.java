package com.metacube.shoppingcart.facade;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import com.metacube.shoppingcart.dao.*;
import com.metacube.shoppingcart.entity.Product;
import com.metacube.shoppingcart.enums.DataBase;
import com.metacube.shoppingcart.enums.EntityType;
import com.metacube.shoppingcart.enums.OperationStatus;
import com.metacube.shoppingcart.factory.Factory;

/**
 * All the business logic for the Product resides here
 * (Singleton class)
 * 
 * @author Amit Sharma 
 *
 */

public class ProductFacadeImp implements ProductFacade{
	private static ProductFacadeImp obj;
	
	BaseDao objectDao =Factory.getInstance(EntityType.Product, DataBase.InMemory);
	InMemoryProductDao productDao = (InMemoryProductDao) objectDao;
	//Singleton object creation
	public static ProductFacadeImp getInstance() {
		if (obj == null) {
			obj = new ProductFacadeImp();
		}
		return obj;
	}
	
	private ProductFacadeImp() {}
	//ends
	/**
	 * Function to return all the products in a list
	 * @return
	 */
	public List<Product> getAll(){
		List<Product> list = new ArrayList<>();
		for(Entry<Integer, Product> e: productDao.getAll().entrySet()){
			list.add((Product)e.getValue());
		}
		return list;
	}
	/**
	 * Returns the product of required Id 
	 * @param productId
	 * @return
	 */
	public Product getProduct(int productId){
		return productDao.getAll().get(productId);
	}
	
	/**
     * Add a new product in the memory
     * @param product
     * @return
     */
	public OperationStatus addProduct(Product product) {
		productDao.addProduct(product);
			return OperationStatus.Product_added;
	}
	
	/**
	 * To remove the product of given Id
	 * @param productId
	 * @return
	 */
	public OperationStatus removeProduct(int productId) {
		if( productDao.getAll().containsKey(productId) ){
			productDao.removeProduct(productId);
			return OperationStatus.Product_removed;
		} else {
			return OperationStatus.No_such_product_found;
		}
	}
	
	/**
	 * To update the product name and price of 
	 * given Product id
	 * @param productId
	 * @param productName
	 * @param price
	 * @return
	 */
	public OperationStatus updateProduct(int productId, String productName, float price ){
		if(productDao.getAll().containsKey(productId)){
			productDao.updateProduct(productId, productName, price);
			return OperationStatus.Update_successfull;
		} else {
			return OperationStatus.No_such_product_found;
		}
	}
}
