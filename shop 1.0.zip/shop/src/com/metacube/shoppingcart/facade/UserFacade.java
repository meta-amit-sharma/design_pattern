package com.metacube.shoppingcart.facade;

import java.util.List;

import com.metacube.shoppingcart.entity.User;
import com.metacube.shoppingcart.enums.OperationStatus;

public interface UserFacade {

	public static UserFacadeImp getInstance(){
		return UserFacadeImp.getInstance();
	}
	
	public List<User> getAll();
	
	 public boolean checkUser(String uid);
	 
	 public OperationStatus addUser(User user);
	 
	 public OperationStatus removeUser(String userId) ;
	 
	 public OperationStatus updateUser(String userId, String userName, String password );
}
