package com.metacube.shoppingcart.entity;

public class BaseEntity {

}
