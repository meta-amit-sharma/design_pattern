package com.metacube.shoppingcart.controller;

import java.util.List;

import com.metacube.shoppingcart.entity.Product;
import com.metacube.shoppingcart.enums.OperationStatus;
import com.metacube.shoppingcart.facade.ProductFacade;


/**
 * Controller to add user or product to memory (handles function calls and acts as a mediator between input and processing)
 * 
 * @author Amit Sharma 
 */
public class ProductController {
	ProductFacade productFacade = ProductFacade.getInstance();
	
	/**
	 * gives a call to add either a user or a product based on the input received
	 * 
	 * @param entity
	 * @param item
	 * @return
	 */
	public OperationStatus add (Product item){
		return productFacade.addProduct (item);
	}
	
	/**
	 * gives a call to return the list of either products or users based on the input
	 * 
	 * @param entity
	 * @return
	 */
	public List<Product> getAll () {
		return productFacade.getAll ();	
	}
	
	/**
	 * gives a call to remove either product or user based on the input
	 * 
	 * @param entity
	 * @param id
	 * @return
	 */
	public OperationStatus remove (int id) {
		return productFacade.removeProduct (id);
	}

	/**
	 * gives a call to update either product or user based on the input
	 * 
	 * @param entity
	 * @param id
	 * @param name
	 * @param price
	 * @return
	 */
	public OperationStatus update ( int id, String name, float price) {
		return productFacade.updateProduct (id, name, price);
		}
}
