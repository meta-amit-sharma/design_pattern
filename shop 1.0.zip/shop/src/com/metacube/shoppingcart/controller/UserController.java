package com.metacube.shoppingcart.controller;

import java.util.List;

import com.metacube.shoppingcart.entity.User;
import com.metacube.shoppingcart.enums.OperationStatus;
import com.metacube.shoppingcart.facade.UserFacade;


/**
 * Controller to add user or product to memory (handles function calls and acts as a mediator between input and processing)
 * 
 * @author Amit Sharma 
 */
public class UserController {
	UserFacade userFacade = UserFacade.getInstance();
	
	/**
	 * gives a call to add either a user or a product based on the input received
	 * 
	 * @param entity
	 * @param item
	 * @return
	 */
	public OperationStatus add (User user){
			return userFacade.addUser (user);
	}
	
	/**
	 * gives a call to return the list of either products or users based on the input
	 * 
	 * @param entity
	 * @return
	 */
	public List<User> getAll () {
		return userFacade.getAll ();	
	}
	
	/**
	 * gives a call to remove either product or user based on the input
	 * 
	 * @param entity
	 * @param id
	 * @return
	 */
	public OperationStatus remove (String userId) {
		return userFacade.removeUser (userId);
	}

	/**
	 * gives a call to update either product or user based on the input
	 * 
	 * @param entity
	 * @param id
	 * @param name
	 * @param xyz
	 * @return
	 */
	public OperationStatus update (String userId, String name, String password) {
		return userFacade.updateUser ( userId, name, password);
	}
}
