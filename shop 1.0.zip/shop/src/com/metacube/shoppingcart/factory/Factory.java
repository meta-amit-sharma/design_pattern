package com.metacube.shoppingcart.factory;

import com.metacube.shoppingcart.dao.BaseDao;
import com.metacube.shoppingcart.dao.InMemoryCartDaoImp;
import com.metacube.shoppingcart.dao.InMemoryProductDaoImp;
import com.metacube.shoppingcart.dao.InMemoryUserDaoImp;
import com.metacube.shoppingcart.enums.DataBase;
import com.metacube.shoppingcart.enums.EntityType;

/**
 * factory to return the respective object
 * (returns singleton object)
 * 
 * @author Amit Sharma
 *
 */

public class Factory{
	
	public static BaseDao getInstance(EntityType objtyp, DataBase dbName) {
		if (dbName == DataBase.InMemory) {
			switch (objtyp) {
				case Product : 
							return new InMemoryProductDaoImp();
				case User : 
							return new InMemoryUserDaoImp();
				case Cart : 
							return new InMemoryCartDaoImp();
			}
		}
	return null;	
	}
	private Factory() {}
		
}
