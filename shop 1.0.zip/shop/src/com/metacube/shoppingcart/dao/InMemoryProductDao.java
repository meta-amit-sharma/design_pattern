package com.metacube.shoppingcart.dao;

import java.util.Map;

import com.metacube.shoppingcart.entity.Product;

public interface InMemoryProductDao extends BaseDao{

	public Map<Integer, Product> getAll();
	
	public void addProduct (Product product);
	
	public void removeProduct(int productID);
	
	public void updateProduct(int productID, String productName, float price);
}
