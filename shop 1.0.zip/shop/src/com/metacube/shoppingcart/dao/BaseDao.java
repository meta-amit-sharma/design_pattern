package com.metacube.shoppingcart.dao;

/**
 * Interface for all DAO activities
 * 
 * @author Amit Sharma 
 *
 */
public interface BaseDao {

	
}
