package com.metacube.shoppingcart.dao;

import java.util.Map;

import com.metacube.shoppingcart.entity.User;

public interface InMemoryUserDao extends BaseDao {

	public Map<String, User> getAll();
	
	public void addUser(User user);
	
	public void removeUser(String userID);
	
	public void updateUser(String userID, String userName, String password);
}
