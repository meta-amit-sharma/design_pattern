package com.metacube.shoppingcart.dao;

import java.util.Map;

import com.metacube.shoppingcart.entity.Product;
import com.metacube.shoppingcart.entity.ShoppingCart;

public interface InMemoryCartDao extends BaseDao {

	public ShoppingCart getCart(String userID);
	
	public Map<String, ShoppingCart> getAllCart();
	
	public void addCart(ShoppingCart cart);
	
	public void removeCart(String userID);
	
	public void addProductToCart(String userID, Product product, int quantity);
	
	public void removeProductFromCart(String userID, Product product);
}
